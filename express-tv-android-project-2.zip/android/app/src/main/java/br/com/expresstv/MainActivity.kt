package br.com.expresstv

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val worker = Executors.newSingleThreadExecutor()
    // Endereço informado pelo usuário. O fornecedor precisa autorizar o uso por apps externos.
    private val server = "http://539w.lat"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(NativeBridge(), "NativeTV")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun login(username: String, password: String) {
            worker.execute {
                val result = try {
                    val u = URLEncoder.encode(username, "UTF-8")
                    val p = URLEncoder.encode(password, "UTF-8")
                    val endpoint = "$server/player_api.php?username=$u&password=$p"
                    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 15000
                        readTimeout = 20000
                    }
                    val account = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val info = JSONObject(account).optJSONObject("user_info")
                    if (info == null || info.optString("auth") != "1") {
                        JSONObject().put("ok", false).put("error", "Usuário ou senha não autorizados.")
                    } else {
                        val streamsConn = (URL("$endpoint&action=get_live_streams").openConnection() as HttpURLConnection).apply {
                            connectTimeout = 15000
                            readTimeout = 30000
                        }
                        val channels = streamsConn.inputStream.bufferedReader().use { it.readText() }
                        streamsConn.disconnect()
                        JSONObject().put("ok", true)
                            .put("channels", org.json.JSONArray(channels))
                            .put("server", server).put("username", username).put("password", password)
                    }
                } catch (e: Exception) {
                    JSONObject().put("ok", false).put("error", "Falha na conexão. Verifique a rede e a compatibilidade do servidor.")
                }
                runOnUiThread {
                    web.evaluateJavascript("window.onNativeLogin(${JSONObject.quote(result.toString())})", null)
                }
            }
        }
    }

    override fun onDestroy() {
        worker.shutdown()
        web.destroy()
        super.onDestroy()
    }
}
