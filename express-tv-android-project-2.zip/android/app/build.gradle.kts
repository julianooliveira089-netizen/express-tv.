plugins { id("com.android.application") }

android {
    namespace = "br.com.expresstv"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.com.expresstv"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
